from django.contrib import admin
from django.contrib.auth.models import User
from django.contrib.auth.admin import UserAdmin

# Register your models here.
from django.contrib import admin
from . import models
admin.site.register(models.Dht11)
admin.site.register(models.Incident)

# Register the OperatorProfile model
from .models import OperatorProfile

class OperatorProfileAdmin(admin.ModelAdmin):
    list_display = ('prenom', 'nom', 'email', 'phone', 'user')
    search_fields = ('prenom', 'nom', 'email', 'user__username')
    list_filter = ('created_at',)
    ordering = ('nom', 'prenom')
    
    # Customize the fields shown in the admin
    fieldsets = (
        ('Informations Personnelles', {
            'fields': ('prenom', 'nom', 'email', 'phone')
        }),
        ('Lien Utilisateur', {
            'fields': ('user',)
        }),
    )
    
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs

# Register the OperatorProfile admin
admin.site.register(OperatorProfile, OperatorProfileAdmin)

# Also keep the custom User admin for general user management
class CustomUserAdmin(UserAdmin):
    # Customize the fields shown in the admin
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_staff', 'is_active', 'date_joined')
    list_filter = ('is_staff', 'is_active', 'is_superuser', 'date_joined')
    search_fields = ('username', 'email', 'first_name', 'last_name')
    ordering = ('username',)
    
    # Customize the fields shown when adding/editing a user
    fieldsets = (
        ('Informations de base', {
            'fields': ('username', 'password')
        }),
        ('Informations personnelles', {
            'fields': ('first_name', 'last_name', 'email')
        }),
        ('Permissions', {
            'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')
        }),
        ('Dates importantes', {
            'fields': ('last_login', 'date_joined')
        }),
    )
    
    # Fields to show when creating a new user
    add_fieldsets = (
        ('Informations de base', {
            'classes': ('wide',),
            'fields': ('username', 'email', 'password1', 'password2'),
        }),
        ('Permissions', {
            'classes': ('wide',),
            'fields': ('is_active', 'is_staff', 'is_superuser', 'groups'),
        }),
    )
    
    def get_queryset(self, request):
        # For the admin interface, we show all users, but we can customize this
        qs = super().get_queryset(request)
        return qs

# Unregister the default User admin and register our custom one
from django.contrib.auth.models import User
admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)