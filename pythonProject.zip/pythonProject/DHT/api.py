from rest_framework import generics
from rest_framework.views import APIView  # <-- AJOUTEZ CETTE LIGNE ICI
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import SessionAuthentication
from django.utils import timezone
from django.core.mail import send_mail
from django.conf import settings
from .models import Dht11, Incident
from .serializers import Dht11Serializer, IncidentSerializer

# Importez les fonctions depuis utils.py
from .utils import send_telegram, send_whatsapp_alert

MIN_OK = 0
MAX_OK = 8
ALERT_THRESHOLD = 8


class DList(generics.ListAPIView):
    serializer_class = Dht11Serializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [SessionAuthentication]
    
    def get_queryset(self):
        queryset = Dht11.objects.all()
        
        # Get date range from query parameters
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')
        
        if start_date:
            from datetime import datetime
            start_datetime = datetime.strptime(start_date, '%Y-%m-%d')
            queryset = queryset.filter(dt__date__gte=start_datetime.date())
        
        if end_date:
            from datetime import datetime
            end_datetime = datetime.strptime(end_date, '%Y-%m-%d')
            queryset = queryset.filter(dt__date__lte=end_datetime.date())
        
        # Order by date, most recent first
        queryset = queryset.order_by('-dt')
        
        return queryset


class Dhtviews(generics.CreateAPIView):
    queryset = Dht11.objects.all()
    serializer_class = Dht11Serializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [SessionAuthentication]

    def perform_create(self, serializer):
        obj = serializer.save()

        t = obj.temp
        if t is None:
            return

        # === GESTION DES INCIDENTS ===
        is_incident = (t < MIN_OK or t > MAX_OK)

        # récupérer l'incident ouvert (s'il existe)
        incident = Incident.objects.filter(is_open=True).order_by("-start_at").first()

        if is_incident:
            # si pas d'incident ouvert -> en créer un
            if incident is None:
                incident = Incident.objects.create(is_open=True, counter=0, max_temp=t)

            incident.counter += 1
            if t > incident.max_temp:
                incident.max_temp = t
            incident.save()

        else:
            # température OK -> si incident ouvert, on le ferme
            if incident is not None:
                incident.is_open = False
                incident.end_at = timezone.now()
                incident.save()

        # === ALERTES EMAIL/TELEGRAM/WHATSAPP ===
        if t > ALERT_THRESHOLD or t < MIN_OK:
            print(f"🚨 Température hors norme détectée: {t}°C (seuil: >{ALERT_THRESHOLD}°C ou <{MIN_OK}°C)")

            # 1) Email
            try:
                send_mail(
                    subject="⚠️ Alerte Température hors norme - DHT11",
                    message=f"""La température a atteint {t:.1f} °C à {obj.dt}.

Capteur: DHT11
Température: {t:.1f}°C
Seuil dépassé: >{ALERT_THRESHOLD}°C ou <{MIN_OK}°C
Date/Heure: {obj.dt}

Hajar NAsri""",
                    from_email=settings.EMAIL_HOST_USER,
                    recipient_list=["hajar.nasri.23@ump.ac.ma"],
                    fail_silently=False,
                )
                print("✅ Email envoyé avec succès")
            except Exception as e:
                print(f"❌ Erreur email: {e}")

            # 2) Telegram
            try:
                telegram_msg = f"""🚨 ALERTE TEMPÉRATURE HORS NORME

📊 Capteur DHT11
🌡 Température: {t:.1f}°C
⚠️ Seuil dépassé: >{ALERT_THRESHOLD}°C ou <{MIN_OK}°C
⏰ Date/Heure: {obj.dt}

La température est hors des limites normales."""

                if send_telegram(telegram_msg):
                    print("✅ Telegram envoyé avec succès")
                else:
                    print("❌ Erreur Telegram")
            except Exception as e:
                print(f"❌ Exception Telegram: {e}")

            # 3) WhatsApp
            try:
                whatsapp_msg = f"""🚨 ALERTE TEMPÉRATURE HORS NORME

📊 Capteur DHT11
🌡 Température: {t:.1f}°C
⚠️ Seuil dépassé: >{ALERT_THRESHOLD}°C ou <{MIN_OK}°C
⏰ Date/Heure: {obj.dt}

HAjar Nasri
La température est hors des limites normales."""

                if send_whatsapp_alert(whatsapp_msg):
                    print("✅ WhatsApp envoyé avec succès")
                else:
                    print("❌ Erreur WhatsApp")
            except Exception as e:
                print(f"❌ Exception WhatsApp: {e}")

            print(f"✅ Toutes les alertes traitées pour température hors norme: {t}°C")


# ---- API incident: état courant ----
# SUPPRIMEZ cette ligne: from rest_framework.views import APIView
# Car elle est déjà importée en haut

class IncidentStatus(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [SessionAuthentication]
    
    def get(self, request):
        incident = Incident.objects.filter(is_open=True).order_by("-start_at").first()
        if not incident:
            return Response({"is_open": False, "counter": 0})
        return Response(IncidentSerializer(incident).data)


# ---- API incident: valider ACK + commentaire (op1/op2/op3) ----
class IncidentUpdateOperator(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [SessionAuthentication]
    
    def post(self, request):
        """
        body:
        {
          "op": 1,
          "ack": true,
          "comment": "..."
        }
        """
        op = int(request.data.get("op", 1))
        ack = bool(request.data.get("ack", False))
        comment = request.data.get("comment", "")

        incident = Incident.objects.filter(is_open=True).order_by("-start_at").first()
        if not incident:
            return Response({"error": "no open incident"}, status=400)

        now = timezone.now()

        if op == 1:
            incident.op1_ack = ack
            incident.op1_comment = comment
            incident.op1_saved_at = now
        elif op == 2:
            incident.op2_ack = ack
            incident.op2_comment = comment
            incident.op2_saved_at = now
        else:
            incident.op3_ack = ack
            incident.op3_comment = comment
            incident.op3_saved_at = now

        incident.save()
        return Response(IncidentSerializer(incident).data)