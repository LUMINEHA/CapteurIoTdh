from django.db import models

class Dht11(models.Model):
    temp = models.FloatField(null=True, blank=True)
    hum = models.FloatField(null=True, blank=True)
    dt = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-dt"]

    def __str__(self):
        return f"{self.dt} -> T={self.temp}°C, H={self.hum}%"

class Incident(models.Model):
    start_at = models.DateTimeField(auto_now_add=True)         # début incident
    end_at   = models.DateTimeField(null=True, blank=True)     # fin incident
    is_open  = models.BooleanField(default=True)

    counter  = models.IntegerField(default=0)                  # nb mesures hors plage
    max_temp = models.FloatField(default=0)

    # opérateurs
    op1_ack = models.BooleanField(default=False)
    op2_ack = models.BooleanField(default=False)
    op3_ack = models.BooleanField(default=False)

    op1_comment = models.TextField(blank=True)
    op2_comment = models.TextField(blank=True)
    op3_comment = models.TextField(blank=True)

    op1_saved_at = models.DateTimeField(null=True, blank=True)
    op2_saved_at = models.DateTimeField(null=True, blank=True)
    op3_saved_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"Incident #{self.id} ({'OPEN' if self.is_open else 'CLOSED'}) counter={self.counter}"

from django.contrib.auth.models import User

class OperatorProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, verbose_name="Utilisateur associé")
    prenom = models.CharField(max_length=50, verbose_name="Prénom")
    nom = models.CharField(max_length=50, verbose_name="Nom")
    email = models.EmailField(verbose_name="Email")
    phone = models.CharField(max_length=20, verbose_name="Téléphone", blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Profil Opérateur"
        verbose_name_plural = "Profils Opérateurs"
        ordering = ["nom", "prenom"]
    
    def __str__(self):
        return f"{self.prenom} {self.nom} ({self.user.username})"
