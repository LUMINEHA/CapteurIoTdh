
# views.py
from django.shortcuts import render
from django.http import JsonResponse
from .models import Dht11
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect
from django.contrib import messages


@login_required
def dashboard(request):
    # Rend la page avec les paramètres de filtre
    context = {}
    
    # Passer les paramètres de filtre au template
    start_date = request.GET.get('start_date', '')
    end_date = request.GET.get('end_date', '')
    
    if start_date:
        context['start_date'] = start_date
    if end_date:
        context['end_date'] = end_date
    
    return render(request, "dashboard.html", context)

def latest_json(request):
    # Fournit la dernière mesure en JSON (sans passer par api.py)
    # Appliquer les filtres de date si présents
    queryset = Dht11.objects.order_by('-dt')
    
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')
    
    if start_date:
        from datetime import datetime
        start_datetime = datetime.strptime(start_date, '%Y-%m-%d')
        queryset = queryset.filter(dt__date__gte=start_datetime.date())
    
    if end_date:
        from datetime import datetime
        end_datetime = datetime.strptime(end_date, '%Y-%m-%d')
        queryset = queryset.filter(dt__date__lte=end_datetime.date())
    
    last = queryset.values('temp', 'hum', 'dt').first()
    
    if not last:
        return JsonResponse({"detail": "no data"}, status=404)
    return JsonResponse({
        "temperature": last["temp"],
        "humidity":    last["hum"],
        "timestamp":   last["dt"].isoformat()
    })
@login_required
def graph_temp(request):
    return render(request, "graph_temp.html")


@login_required
def graph_hum(request):
    return render(request, "graph_hum.html")
from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from .models import Incident
import csv

@login_required
def incident_archive(request):
    # Incidents fermés uniquement
    incidents = Incident.objects.filter(is_open=False).order_by("-end_at")
    return render(request, "incident_archive.html", {"incidents": incidents})

@login_required
def incident_detail(request, pk):
    # Détails d’un incident précis
    incident = get_object_or_404(Incident, pk=pk)
    return render(request, "incident_detail.html", {"incident": incident})

@login_required
def incident_export_csv(request):
    # Export all incidents as CSV
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="incidents_export.csv"'
    
    writer = csv.writer(response)
    writer.writerow([
        'ID', 'Statut', 'Début', 'Fin', 'Compteur', 'Temp Max',
        'Op1 ACK', 'Op1 Commentaire', 'Op1 Validation',
        'Op2 ACK', 'Op2 Commentaire', 'Op2 Validation',
        'Op3 ACK', 'Op3 Commentaire', 'Op3 Validation'
    ])
    
    incidents = Incident.objects.all().order_by('-start_at')
    for incident in incidents:
        writer.writerow([
            incident.id,
            'OUVERT' if incident.is_open else 'FERMÉ',
            incident.start_at.strftime('%d/%m/%Y %H:%M:%S'),
            incident.end_at.strftime('%d/%m/%Y %H:%M:%S') if incident.end_at else 'N/A',
            incident.counter,
            incident.max_temp,
            incident.op1_ack,
            incident.op1_comment,
            incident.op1_saved_at.strftime('%d/%m/%Y %H:%M:%S') if incident.op1_saved_at else 'N/A',
            incident.op2_ack,
            incident.op2_comment,
            incident.op2_saved_at.strftime('%d/%m/%Y %H:%M:%S') if incident.op2_saved_at else 'N/A',
            incident.op3_ack,
            incident.op3_comment,
            incident.op3_saved_at.strftime('%d/%m/%Y %H:%M:%S') if incident.op3_saved_at else 'N/A',
        ])
    
    return response

@login_required
def incident_export_single_csv(request, pk):
    # Export single incident as CSV
    incident = get_object_or_404(Incident, pk=pk)
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="incident_{incident.id}_details.csv"'
    
    writer = csv.writer(response)
    writer.writerow(['Champ', 'Valeur'])
    writer.writerow(['ID', incident.id])
    writer.writerow(['Statut', 'OUVERT' if incident.is_open else 'FERMÉ'])
    writer.writerow(['Début', incident.start_at.strftime('%d/%m/%Y %H:%M:%S')])
    writer.writerow(['Fin', incident.end_at.strftime('%d/%m/%Y %H:%M:%S') if incident.end_at else 'N/A'])
    writer.writerow(['Compteur', incident.counter])
    writer.writerow(['Temp Max', incident.max_temp])
    writer.writerow(['', ''])  # Empty row for separation
    writer.writerow(['Opérateur 1', ''])
    writer.writerow(['  ACK', incident.op1_ack])
    writer.writerow(['  Commentaire', incident.op1_comment])
    writer.writerow(['  Validé le', incident.op1_saved_at.strftime('%d/%m/%Y %H:%M:%S') if incident.op1_saved_at else 'N/A'])
    writer.writerow(['', ''])  # Empty row for separation
    writer.writerow(['Opérateur 2', ''])
    writer.writerow(['  ACK', incident.op2_ack])
    writer.writerow(['  Commentaire', incident.op2_comment])
    writer.writerow(['  Validé le', incident.op2_saved_at.strftime('%d/%m/%Y %H:%M:%S') if incident.op2_saved_at else 'N/A'])
    writer.writerow(['', ''])  # Empty row for separation
    writer.writerow(['Opérateur 3', ''])
    writer.writerow(['  ACK', incident.op3_ack])
    writer.writerow(['  Commentaire', incident.op3_comment])
    writer.writerow(['  Validé le', incident.op3_saved_at.strftime('%d/%m/%Y %H:%M:%S') if incident.op3_saved_at else 'N/A'])
    
    return response

@login_required
def export_sensor_data_csv(request):
    # Export sensor data with date filtering
    from django.utils import timezone
    from datetime import datetime
    
    # Get date range from GET parameters
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')
    
    # Build the query
    queryset = Dht11.objects.all()
    
    if start_date:
        start_datetime = datetime.strptime(start_date, '%Y-%m-%d')
        queryset = queryset.filter(dt__date__gte=start_datetime.date())
    
    if end_date:
        end_datetime = datetime.strptime(end_date, '%Y-%m-%d')
        queryset = queryset.filter(dt__date__lte=end_datetime.date())
    
    # Order by date
    queryset = queryset.order_by('dt')
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="sensor_data_export.csv"'
    
    writer = csv.writer(response)
    writer.writerow(['Date/Heure', 'Température (°C)', 'Humidité (%)'])
    
    for record in queryset:
        writer.writerow([
            record.dt.strftime('%d/%m/%Y %H:%M:%S'),
            record.temp,
            record.hum
        ])
    
    return response

@login_required
def export_sensor_data_json(request):
    # Export sensor data as JSON with date filtering
    from django.utils import timezone
    from datetime import datetime
    import json
    
    # Get date range from GET parameters
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')
    
    # Build the query
    queryset = Dht11.objects.all()
    
    if start_date:
        start_datetime = datetime.strptime(start_date, '%Y-%m-%d')
        queryset = queryset.filter(dt__date__gte=start_datetime.date())
    
    if end_date:
        end_datetime = datetime.strptime(end_date, '%Y-%m-%d')
        queryset = queryset.filter(dt__date__lte=end_datetime.date())
    
    # Order by date
    queryset = queryset.order_by('dt')
    
    # Prepare data
    data = []
    for record in queryset:
        data.append({
            'datetime': record.dt.isoformat(),
            'temperature': record.temp,
            'humidity': record.hum,
            'formatted_datetime': record.dt.strftime('%d/%m/%Y %H:%M:%S')
        })
    
    response = HttpResponse(
        json.dumps(data, indent=2),
        content_type='application/json'
    )
    response['Content-Disposition'] = 'attachment; filename="sensor_data_export.json"'
    
    return response

@login_required
def graph_combined(request):
    # Combined temperature and humidity graph page
    context = {}
    
    # Pass date filter parameters to template
    start_date = request.GET.get('start_date', '')
    end_date = request.GET.get('end_date', '')
    
    if start_date:
        context['start_date'] = start_date
    if end_date:
        context['end_date'] = end_date
    
    return render(request, "graph_combined.html", context)

from django.contrib.auth.decorators import login_required, user_passes_test

# Check if user is admin
def is_admin(user):
    return user.is_staff


def login_view(request):
    from django.contrib.auth import authenticate, login
    from django.shortcuts import render, redirect
    from django.contrib import messages
    
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            # Redirect based on user role
            if user.is_staff:  # Admin user
                return redirect('admin_panel')
            else:  # Regular operator
                return redirect('dashboard')
        else:
            messages.error(request, "Nom d'utilisateur ou mot de passe incorrect")
    
    return render(request, 'login.html')


def logout_view(request):
    from django.contrib.auth import logout
    from django.shortcuts import redirect
    
    logout(request)
    return redirect('login')

@login_required
@user_passes_test(is_admin)
def admin_panel(request):
    # Admin panel to manage operators and incidents
    from django.shortcuts import render, get_object_or_404
    from django.http import HttpResponse, JsonResponse
    from django.contrib.auth.models import User
    from .models import Incident
    
    if request.method == 'POST':
        # Handle incident deletion
        if 'delete_incident' in request.POST:
            incident_id = request.POST.get('incident_id')
            incident = get_object_or_404(Incident, pk=incident_id)
            incident.delete()
            return HttpResponse(status=204)  # No content response
        
        # Handle operator creation
        elif 'username' in request.POST:
            username = request.POST.get('username')
            email = request.POST.get('email', '')
            password = request.POST.get('password')
            is_staff = request.POST.get('is_staff', False)
            
            # Create new user/operator
            user = User.objects.create_user(
                username=username,
                email=email,
                password=password
            )
            
            if is_staff:
                user.is_staff = True
                user.save()
            
            # Create an OperatorProfile for this user
            from .models import OperatorProfile
            operator_profile = OperatorProfile.objects.create(
                user=user,
                prenom=username,  # Using username as first name by default
                nom="Operator",   # Default last name
                email=email
            )
            
            return JsonResponse({'status': 'success', 'message': f'Opérateur {username} créé avec succès!'})
    
    # Get all incidents for admin view
    incidents = Incident.objects.all().order_by('-start_at')
    
    context = {
        'incidents': incidents,
    }
    return render(request, "admin_panel.html", context)
