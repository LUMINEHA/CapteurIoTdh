from django.urls import path
from . import views
from . import api


urlpatterns = [
    path("api/", api.DList.as_view(), name="json"),
    path("api/post",api.Dhtviews.as_view(),name='json'),
    path("", views.dashboard, name="dashboard"),
    path("latest/", views.latest_json, name="latest_json"),
    path("graph_temp/", views.graph_temp, name="graph_temp"),
    path("graph_hum/", views.graph_hum, name="graph_hum"),
    path("incident/status/", api.IncidentStatus.as_view(), name="incident_status"),
    path("incident/update/", api.IncidentUpdateOperator.as_view(), name="incident_update"),
    path("incident/archive/", views.incident_archive, name="incident_archive"),
    path("incident/<int:pk>/", views.incident_detail, name="incident_detail"),
    path("incident/export/csv/", views.incident_export_csv, name="incident_export_csv"),
    path("incident/<int:pk>/export/csv/", views.incident_export_single_csv, name="incident_export_single_csv"),
    path("export/csv/", views.export_sensor_data_csv, name="export_sensor_data_csv"),
    path("export/json/", views.export_sensor_data_json, name="export_sensor_data_json"),
    path("graph_combined/", views.graph_combined, name="graph_combined"),
    path("admin/", views.admin_panel, name="admin_panel"),
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),

    ]
