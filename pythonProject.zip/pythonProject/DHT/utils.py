import requests
from django.conf import settings
from twilio.rest import Client


def send_telegram(text: str) -> bool:
    """Envoie un message Telegram via l'API officielle. Retourne True si OK."""
    token = settings.TELEGRAM_BOT_TOKEN
    chat_id = settings.TELEGRAM_CHAT_ID
    
    # Check if credentials are set
    if not token or not chat_id:
        print("Telegram notifications are disabled (no credentials set)")
        return False
    
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    try:
        r = requests.post(url, data={"chat_id": chat_id, "text": text})  # Corrigé: "chat_id"
        print(f"Telegram response: {r.status_code}, {r.text}")  # Debug info
        return r.ok
    except Exception as e:
        print(f"Erreur Telegram: {e}")  # Debug info
        return False


def send_whatsapp_alert(message: str) -> bool:
    """Envoie une alerte WhatsApp via Twilio. Retourne True si OK."""
    
    # Check if credentials are set
    if not settings.TWILIO_ACCOUNT_SID or not settings.TWILIO_AUTH_TOKEN or not settings.TWILIO_WHATSAPP_NUMBER or not settings.WHATSAPP_RECIPIENT:
        print("WhatsApp notifications are disabled (no credentials set)")
        return False
    
    try:
        client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)

        # Remove any spaces from the recipient number to ensure proper format
        recipient_number = settings.WHATSAPP_RECIPIENT.replace(' ', '')

        msg = client.messages.create(
            from_=settings.TWILIO_WHATSAPP_NUMBER,
            body=message,
            to=recipient_number
        )
        print(f"WhatsApp message SID: {msg.sid}")
        return True
    except Exception as e:
        print(f"Erreur WhatsApp: {e}")
        return False