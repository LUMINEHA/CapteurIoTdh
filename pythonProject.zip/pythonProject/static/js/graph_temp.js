// static/js/graph_temp.js

async function loadTempHistory() {
    try {
        console.log("Chargement de l'historique de température...");

        // Get date filters from the form
        const startDate = document.getElementById('startDate')?.value;
        const endDate = document.getElementById('endDate')?.value;
        
        // Build URL with parameters
        let url = "/api/";
        const params = [];
        
        if (startDate) params.push(`start_date=${startDate}`);
        if (endDate) params.push(`end_date=${endDate}`);
        
        if (params.length > 0) {
            url += '?' + params.join('&');
        }
        
        // Récupérer les données depuis l'API
        const response = await fetch(url);

        if (!response.ok) {
            throw new Error(`Erreur HTTP: ${response.status}`);
        }

        // L'API retourne directement un tableau
        const dataArray = await response.json();
        console.log(`${dataArray.length} points de données reçus`);

        if (!Array.isArray(dataArray) || dataArray.length === 0) {
            document.getElementById("chartContainer").innerHTML =
                "<p style='text-align: center; color: gray; padding: 40px;'>Aucune donnée de température disponible</p>";
            return;
        }

        // Inverser pour avoir les données les plus récentes à droite
        const reversedData = [...dataArray].reverse();

        // Extraire les labels (dates) et températures
        const labels = reversedData.map(row => {
            try {
                const date = new Date(row.dt);
                return date.toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit'
                });
            } catch (e) {
                return '--:--';
            }
        });

        const temperatures = reversedData.map(row => parseFloat(row.temp) || 0);

        // Trouver min/max pour les limites du graphique
        const minTemp = Math.min(...temperatures);
        const maxTemp = Math.max(...temperatures);

        // Créer le graphique
        const ctx = document.getElementById("tempChart");
        if (!ctx) {
            throw new Error("Canvas #tempChart non trouvé");
        }

        // Détruire l'ancien graphique s'il existe
        if (window.tempChartInstance) {
            window.tempChartInstance.destroy();
        }

        window.tempChartInstance = new Chart(ctx, {
            type: "line",
            data: {
                labels: labels,
                datasets: [{
                    label: "Température (°C)",
                    data: temperatures,
                    borderColor: "#e74c3c",
                    backgroundColor: "rgba(231, 76, 60, 0.1)",
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: "#e74c3c",
                    pointRadius: 4,
                    pointHoverRadius: 7
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        callbacks: {
                            label: function(context) {
                                return `${context.dataset.label}: ${context.parsed.y}°C`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Heure de la journée',
                            font: {
                                size: 14,
                                weight: 'bold'
                            }
                        },
                        grid: {
                            color: 'rgba(0,0,0,0.05)'
                        }
                    },
                    y: {
                        beginAtZero: false,
                        min: minTemp - 2,
                        max: maxTemp + 2,
                        title: {
                            display: true,
                            text: 'Température (°C)',
                            font: {
                                size: 14,
                                weight: 'bold'
                            }
                        },
                        grid: {
                            color: 'rgba(0,0,0,0.05)'
                        },
                        ticks: {
                            callback: function(value) {
                                return value + '°C';
                            }
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'nearest'
                },
                animation: {
                    duration: 1000,
                    easing: 'easeOutQuart'
                }
            }
        });

        console.log("Graphique de température créé avec succès!");

    } catch (error) {
        console.error("Erreur lors du chargement du graphique de température:", error);

        const container = document.getElementById("chartContainer");
        if (container) {
            container.innerHTML = `
                <div style="
                    background: #fff3f3;
                    border: 2px solid #ff6b6b;
                    border-radius: 8px;
                    padding: 30px;
                    margin: 20px 0;
                    color: #d32f2f;
                    text-align: center;
                ">
                    <h3 style="margin-top: 0;">⚠️ Erreur de chargement</h3>
                    <p><strong>${error.message}</strong></p>
                    <p>Veuillez vérifier la console pour plus de détails (F12 > Console).</p>
                    <button onclick="location.reload()" style="
                        margin-top: 15px;
                        padding: 10px 20px;
                        background: #d32f2f;
                        color: white;
                        border: none;
                        border-radius: 4px;
                        cursor: pointer;
                        font-size: 16px;
                    ">
                        Rafraîchir la page
                    </button>
                </div>
            `;
        }
    }
}

// Attendre que la page soit chargée
document.addEventListener("DOMContentLoaded", loadTempHistory);